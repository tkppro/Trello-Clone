# Trello-Clone
A trello clone Website built by Vuejs 2.5 and Laravel 6.x and using Vuetify as template
## Requirements:
* composer
* PHP 7.x
* npm

## How to run?
```
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan serve
npm run dev
```
